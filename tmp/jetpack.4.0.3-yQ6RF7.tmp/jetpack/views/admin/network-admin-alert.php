<div id="message" class="updated jetpack-message jp-connect" style="display:block !important;">
		<div class="jetpack-wrap-container">
			<div class="jetpack-text-container">
				<h2>
					<?php echo $data['notice']; ?>
				</h2>
			</div>
		</div>
</div>
